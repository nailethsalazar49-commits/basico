document.addEventListener("DOMContentLoaded", ()=>{
    const skillsItemsNav = document.querySelectorAll(".itemSkillNav");
    const skillsContent = document.querySelectorAll(".skillContent");

    skillsItemsNav.forEach((item, index) => {
        item.addEventListener("click", () => {
            skillsContent.forEach((skill) => skill.classList.remove("view"));
            skillsContent.forEach((skill) => skill.classList.add("hidden"));
            skillsItemsNav.forEach((skill) => skill.classList.remove("selected"));
            skillsContent[index].classList.remove("hidden");
            skillsContent[index].classList.add("view");
            item.classList.add("selected");
        })
    });
})